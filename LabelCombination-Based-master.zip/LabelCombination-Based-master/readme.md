﻿# BinaryRelevance Based
## Dataset
[http://mulan.sourceforge.net/datasets-mlc.html][1]

### yeast
|name | domain | instances |nominal	|numeric|labels|cardinality	|density|distinct|
| ------ | ------ | ------ |------ |------ |------ |------ |------ |------ |
| yeast| biology | 2417	 |0|103	|14|4.237|0.303	|198|

## Evaluation
|evaluation criterion |LP||||
|---|---|---|---|---|
|hamming loss|||||
|ranking loss|||||
|one error|||||

## Requrements
- Python 3.6
- numpy 1.13.3
- scikit-learn 0.19.1

## Parameter


## Reference
[Random k-labelsets for multi-label classification,IEEE Transactions on Knowledge and Data Engineering, vol. 23,no. 7, pp. 1079–1089, 2011.][2]


  [1]: http://mulan.sourceforge.net/datasets-mlc.html
  [2]: https://ieeexplore.ieee.org/abstract/document/5567103




